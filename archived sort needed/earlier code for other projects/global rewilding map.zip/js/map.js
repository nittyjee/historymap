
    <!--ADD MAPS TO COMPARE-->

      mapboxgl.accessToken =
        "pk.eyJ1Ijoibml0dHlqZWUiLCJhIjoid1RmLXpycyJ9.NFk875-Fe6hoRCkGciG8yQ";

      //Satellite Map
      var beforeMap = new mapboxgl.Map({
        container: "before",
        //With Labels
        //style: 'mapbox://styles/nittyjee/ck3azcbul18sv1dmgni6bw44o',
        //Without Labels
        style: "mapbox://styles/nittyjee/ck0sihu5wer5p1crswvqheao7",
        center: [-102.03, 38.19],
        hash: true,
        zoom: 3.91,
      });

      //Overlay Map
      var map = new mapboxgl.Map({
        container: "map",
        style: "mapbox://styles/nittyjee/ck312iiwh1jmy1cpmq51odz7o",

        //Map with labels
        //Note how labels do not appear because of other layers
        //style: 'mapbox://styles/nittyjee/ck36wxmuu3dif1cqr50vesar9',

        hash: true,
        zoom: 3.91,
        center: [-102.03, 38.19],
      });

      //ADDING HOVER STUFF
      var hoveredStateId = null;

      //BASEMAP MENU SWITCHING FUNCTIONALITY
      var layerList = document.getElementById("basemapmenu");
      var inputs = layerList.getElementsByTagName("input");

      function switchLayer(layer) {
        var layerId = layer.target.id;

        //MY LINE:
        beforeMap.setStyle("mapbox://styles/nittyjee/" + layerId);

        //ORIGINAL LINE:
        //map.setStyle('mapbox://styles/mapbox/' + layerId);
      }

      for (var i = 0; i < inputs.length; i++) {
        inputs[i].onclick = switchLayer;
      }

      /////////////////////////////
      //ADD NAVIGATION CONTROL (ZOOM IN AND OUT)
      /////////////////////////////

      //Before map
      var nav = new mapboxgl.NavigationControl();
      beforeMap.addControl(nav, "bottom-right");

      //After map
      var nav = new mapboxgl.NavigationControl();
      map.addControl(nav, "bottom-right");



      /////////////////////////////
      //LAYER CHANGING
      /////////////////////////////

      //BASEMAP SWITCHING
      map.on("style.load", function () {
        //on the 'style.load' event, switch "basemaps" and then re-add layers
        //this is necessary because basemaps aren't a concept in Mapbox, all layers are added via the same primitives
        console.log("style change");
        switchStyle();
        var sliderVal = $("#date").val();
        var yr = parseInt(moment.unix(sliderVal).format("YYYY"));
        var date = parseInt(moment.unix(sliderVal).format("YYYYMMDD"));
        console.log(sliderVal);
        console.log(yr);
        console.log(date);
        setLayers();
        addLayers(yr, date);
      });



