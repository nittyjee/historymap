      //ADD COMPARING FOR SWIPE
      var poopMap = new mapboxgl.Compare(beforeMap, map, {
        // Set this to enable comparing two maps by mouse movement:
        // mousemove: true
      });

      $(document).ready(function () {
        // Toogle Treeview in studio menu
        $("#studioMenu").on("click", ".caret", function (e) {
          $(this).parent().parent().find(".nested").toggleClass("active");
          $(this).toggleClass("caret-down");
        });

        // Collapse the layer menu
        var selectedLayer = "",
          selectedColor = "",
          selectedLayerStyles = {};
		  
        // Select the layer on the list
        $("#studioMenu").on("dblclick", ".layer-menu", function (e) {
           //.css({ "display": "none" });

          if($(this).parent().find(".icon-eye").hasClass("display-none")) {
			   $(this).parent().find(".icon-noeye").trigger('click');
          } else {
		       $(this).parent().find(".icon-eye").trigger('click');
		  }
		  /*
		  if(!$(this).parent().find(".icon-eye").hasClass("display-none")) {
		      console.log("-");
		      $(this).parent().find(".icon-eye").trigger('click');
		  }
		  */
          //console.log($(this).parent().find(".icon-eye"));
        });
		
        // Select the layer on the list
        $("#studioMenu").on("click", ".layer-menu", function (e) {
          const attrName = $(this).attr("attrName");
          const attrParent = $(this).attr("attrParent");
          const allTiles = document.getElementsByClassName("studio-layer-tile");
          $("#studioMenuLayerEdit").addClass("disabled");
         
		 

          for (var i = 0; i < allTiles.length; i++) {
            if (allTiles[i].getAttribute("attrName") === attrName) {
              if (attrName.includes("_title")) {
                const childNodes = allTiles[
                  i
                ].parentElement.getElementsByClassName("studio-layer-tile");
                if (
                  allTiles[i].classList.contains("studio-layer-tile-active")
                ) {
                  for (var j = 0; j < childNodes.length; j++) {
                    childNodes[j].classList.remove("studio-layer-tile-active");
                  }
                } else {
                  selectedLayer = attrName;
                  $("#studioMenuLayerEdit").removeClass("disabled");
                  for (var n = 0; n < layerGroup.length; n++) {
                    if (
                      layerGroup[n].title ===
                      selectedLayer.replace(/_title/g, "")
                    ) {
                      var flag = false;
                      for (var m = 0; m < layerGroup[n].childs.length; m++) {
                        if (
                          map.getLayoutProperty(
                            layerGroup[n].childs[m],
                            "visibility"
                          ) === "visible"
                        ) {
                          flag = true;
                        }
                      }
                      if (flag) {
                        $("#studioVisibleIcon").addClass("display-none");
                        $("#studioDisableIcon").removeClass("display-none");
                      } else {
                        $("#studioVisibleIcon").removeClass("display-none");
                        $("#studioDisableIcon").addClass("display-none");
                      }
                    }
                  }
                  const childLayers = layerGroup;
                  for (var j = 0; j < childNodes.length; j++) {
                    childNodes[j].classList.add("studio-layer-tile-active");
                  }
                }
              } else {
                if (
                  !allTiles[i].parentElement.parentElement
                    .getElementsByClassName("studio-layer-tile")[0]
                    .classList.contains("studio-layer-tile-active")
                ) {
                  allTiles[i].classList.toggle("studio-layer-tile-active");
                }
                if (
                  allTiles[i].classList.contains("studio-layer-tile-active")
                ) {
                  selectedLayer = attrName;
                  $("#studioMenuLayerEdit").removeClass("disabled");
                  const visible = map.getLayoutProperty(
                    selectedLayer,
                    "visibility"
                  );
                  if (visible === "visible") {
                    $("#studioVisibleIcon").addClass("display-none");
                    $("#studioDisableIcon").removeClass("display-none");
                  } else {
                    $("#studioVisibleIcon").removeClass("display-none");
                    $("#studioDisableIcon").addClass("display-none");
                  }
                }
                for (var j = 0; j < allTiles.length; j++) {
                  if (allTiles[j].getAttribute("attrName") !== attrName) {
                    allTiles[j].classList.remove("studio-layer-tile-active");
                  }
                }
              }
            } else {
              if (
                allTiles[i].getAttribute("attrParent") !== attrParent &&
                allTiles[i].getAttribute("attrName") !== attrParent &&
                allTiles[i].getAttribute("attrName") !== attrName &&
                allTiles[i].getAttribute("attrParent") !== attrName
              ) {
                allTiles[i].classList.remove("studio-layer-tile-active");
              }
            }
          }
        });

        // click the info button on the taskbar
        $("#studioMenuLayerEdit").on("click", "#studioInfoIcon", function (e) {
          e.preventDefault();
          e.stopPropagation();
          if ($("#studioMenuLayerEdit").hasClass("disabled")) return;
        });

        // click the disable icon on the taskbar
        $("#studioMenuLayerEdit").on("click", "#studioDisableIcon", function (
          e
        ) {
          e.preventDefault();
          e.stopPropagation();
          if ($("#studioMenuLayerEdit").hasClass("disabled")) return;
          if (selectedLayer.includes("_title")) {
            for (var n = 0; n < layerGroup.length; n++) {
              if (
                layerGroup[n].title === selectedLayer.replace(/_title/g, "")
              ) {
                for (var m = 0; m < layerGroup[n].childs.length; m++) {
                  map.setLayoutProperty(
                    layerGroup[n].childs[m],
                    "visibility",
                    "none"
                  );
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_noeye`).toggleClass("display-none");
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_eye`).toggleClass("display-none");
                }
								$(`#${selectedLayer.replace(/ /g, "_")}_noeye`).toggleClass("display-none");
								$(`#${selectedLayer.replace(/ /g, "_")}_eye`).toggleClass("display-none");
                $("#studioDisableIcon").toggleClass("display-none");
                $("#studioVisibleIcon").toggleClass("display-none");
              }
            }
          } else {
            map.setLayoutProperty(selectedLayer, "visibility", "none");
						$(`#${selectedLayer.replace(/ /g, "_")}_noeye`).toggleClass("display-none");
						$(`#${selectedLayer.replace(/ /g, "_")}_eye`).toggleClass("display-none");
            $("#studioDisableIcon").toggleClass("display-none");
            $("#studioVisibleIcon").toggleClass("display-none");
          }
        });

        // click the enable icon on the taskbar
        $("#studioMenuLayerEdit").on("click", "#studioVisibleIcon", function (
          e
        ) {
          e.preventDefault();
          e.stopPropagation();
          if ($("#studioMenuLayerEdit").hasClass("disabled")) return;
          if (selectedLayer.includes("_title")) {
            for (var n = 0; n < layerGroup.length; n++) {
              if (
                layerGroup[n].title === selectedLayer.replace(/_title/g, "")
              ) {
                for (var m = 0; m < layerGroup[n].childs.length; m++) {
                  map.setLayoutProperty(
                    layerGroup[n].childs[m],
                    "visibility",
                    "visible"
                  );
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_noeye`).toggleClass("display-none");
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_eye`).toggleClass("display-none");
                }
								$(`#${selectedLayer.replace(/ /g, "_")}_noeye`).toggleClass("display-none");
								$(`#${selectedLayer.replace(/ /g, "_")}_eye`).toggleClass("display-none");
                $("#studioDisableIcon").toggleClass("display-none");
                $("#studioVisibleIcon").toggleClass("display-none");
              }
            }
          } else {
            map.setLayoutProperty(selectedLayer, "visibility", "visible");
						$(`#${selectedLayer.replace(/ /g, "_")}_noeye`).toggleClass("display-none");
						$(`#${selectedLayer.replace(/ /g, "_")}_eye`).toggleClass("display-none");
            $("#studioDisableIcon").toggleClass("display-none");
            $("#studioVisibleIcon").toggleClass("display-none");
          }
        });

        // click the disable icon on the list
        $("#studioLayerGroup").on("click", ".icon-noeye", function (e) {
          e.preventDefault();
          e.stopPropagation();
          if ($("#studioMenuLayerEdit").hasClass("disabled")) return;
					if ($(this).parent()[0].getAttribute("attrName") !== selectedLayer) return;
          if (selectedLayer.includes("_title")) {
		    //console.log("1");
            for (var n = 0; n < layerGroup.length; n++) {
              if (
                layerGroup[n].title === selectedLayer.replace(/_title/g, "")
              ) {
                for (var m = 0; m < layerGroup[n].childs.length; m++) {
                  map.setLayoutProperty(
                    layerGroup[n].childs[m],
                    "visibility",
                    "none"
                  );
				                    if(!$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_noeye`).hasClass("display-none"))
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_noeye`).toggleClass("display-none");
									if($(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_eye`).hasClass("display-none"))
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_eye`).toggleClass("display-none");
                }
                $(this).toggleClass("display-none");
				
				var childPos = $(this).parent()[0].childNodes.length -4;
				//console.log("pos");
				//console.log(childPos);
                $(this)
                  .parent()[0]
				  .childNodes[childPos].classList.toggle("display-none");
                  //.lastElementChild.classList.toggle("display-none");
				  
								$("#studioDisableIcon").toggleClass("display-none");
            		$("#studioVisibleIcon").toggleClass("display-none");
              }
            }
          } else {
		    //console.log("2");
            map.setLayoutProperty(selectedLayer, "visibility", "none");
            $(this).toggleClass("display-none");
            $(this)
              .parent()[0]
              .lastElementChild.classList.toggle("display-none");
						$("#studioDisableIcon").toggleClass("display-none");
            $("#studioVisibleIcon").toggleClass("display-none");
						for (var n = 0; n < layerGroup.length; n++) {
							if (layerGroup[n].title === $(this).parent()[0].getAttribute("attrParent").replace(/_title/g, "")) {
								if (layerGroup[n].childs.length === 1) {
									$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_noeye`).toggleClass("display-none");
									$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_eye`).toggleClass("display-none");
								} else {
									var flag = false;
									for (var m = 0; m < layerGroup[n].childs.length; m++) {
										if (
											map.getLayoutProperty(
												layerGroup[n].childs[m],
												"visibility"
											) === "visible"
										) {
											flag = true;
										}
									}
									if (flag) {
										$("#studioVisibleIcon").addClass("display-none");
										$("#studioDisableIcon").removeClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_noeye`).removeClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_eye`).addClass("display-none");
									} else {
										$("#studioVisibleIcon").removeClass("display-none");
										$("#studioDisableIcon").addClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_noeye`).addClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_eye`).removeClass("display-none");
									}
								}								
							}
						}
          }
        });

        $("#start-modal").on("click", function () {
		  
		  $("div#modal-title").html("About");
      $("div.modal-body").html(" While our landscape has been ravaged, with the little left wild" +
          " scattered, it turns out that wildlife areas can be connected and" +
          " expanded, and new ones created in a way that is achievable and practical." +
          "<p>" +
          "The land that is undevelopment and unsuitable for crops is often the" +
          " highest value for cores and corridors, and has the lowest land value," +
          " with steep slopes, loose ground, and regular flooding. Because of its" +
          " practicality, this land is a priority for rewilding." +
          "<p>" +
          "This map is an indispensable for establishing wildlife cores and" +
          " corridors. It shows the rewilding priority land and are swiped back" +
          " and forth for comparison with a satellite photograph that makes the" +
          " landscape visible at a given point in time. It reveal potentials" +
          " otherwise unseen, with the areas that are most strategic for the" +
          " expansion and creation of  core habitats. The various map layers" +
          " can be used to find corridors between the cores" +
          "<p>" +
          "More easily than ever, people can know where to look, where they" +
          " would then walk and assess the land in person. As rewilding takes" +
          " place, the map would be adjusted and the strategy would" +
          " continually evolve." +
          "</p>" +
          "<p></p>" +
          "<hr />" +
          "<font size='4.5'> <b>Outline of Map Layers:</b></font>" +
          "<p>" +
          "<img src='modal/map_elements.jpg' width='100%' />" +
          "</p>");
		  
          $("#modal-button").trigger('click');
      

    });
    
    $("#start-modal2").on("click", function () {
		  
		  $("div#modal-title").html("Guide");
      $("div.modal-body").html("There will be a guide to this map soon. In the meantime, here's a quick video:" +
      //"<p>" +
      //"<iframe width='560' height='315' src='https://docs.google.com/document/d/e/2PACX-1vQ7NvezCmnr4OafWMBydExtB4ccYywsq71iqpNZfNpnLqeabOLRTuiW2i-tTboZIyoYpDXuQQSRINgE/pub?embedded=true'></iframe>"
      "<p>" +
      "<iframe width='560' height='315' src='https://www.youtube.com/embed/bWnoW9OiETY' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"
     
      );
      
      




		  
      $("#modal-button").trigger('click');
      

		});

        // click the enable icon modal popup
        $("#studioLayerGroup").on("click", ".info-icon", function (e) {
          e.preventDefault();
          e.stopPropagation();
		  
		  var popupLayer = $(this).parent()[0].getAttribute("attrName").replace(/_title/g,"");
		  var popupBody = "<ol>";
      
      /*
      // REMOVED COLOR EXPLANATIONS, IT WAS UGLY

		  for (var n = 0; n < layerGroup.length; n++) {
		      if( layerGroup[n].title === popupLayer ) {
			      for (var m = 0; m < layerGroup[n].childs.length; m++) {
				     var popupClrs = "";
				     for (var k = 0; k < layerColors.length; k++) {
					    if(layerColors[k].layerName === layerGroup[n].childs[m]) {
						    for (var j = 0; j < layerColors[k].colors.length; j++) {
							    popupClrs += "<div style='display: inline-block; width: 23px; height: 11px; background-color:" + layerColors[k].colors[j] + "'></div> ";
							}
						}
					 }
				  
				      popupBody += "<li>" + layerGroup[n].childs[m] + " " + popupClrs + "</li>";
				  }
			  }
      }
      */
		  
		  popupBody += "</ol>";
		  
		  if(popupModalHTMLs[popupLayer])
		      popupBody += popupModalHTMLs[popupLayer];
		  
		  $("div#modal-title").html(popupLayer);
      $("div.modal-body").html(popupBody);
      
      
		  
		  $("#modal-button").trigger('click');
		  
		});

       

        // click the enable icon on the list
        $("#studioLayerGroup").on("click", ".icon-eye", function (e) {
          e.preventDefault();
          e.stopPropagation();
          if ($("#studioMenuLayerEdit").hasClass("disabled")) return;
					if ($(this).parent()[0].getAttribute("attrName") !== selectedLayer) return;
          if (selectedLayer.includes("_title")) {
            for (var n = 0; n < layerGroup.length; n++) {
              if (
                layerGroup[n].title === selectedLayer.replace(/_title/g, "")
              ) {
                for (var m = 0; m < layerGroup[n].childs.length; m++) {
                  map.setLayoutProperty(
                    layerGroup[n].childs[m],
                    "visibility",
                    "visible"
                  );                
				                    if($(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_noeye`).hasClass("display-none"))
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_noeye`).toggleClass("display-none");
									if(!$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_eye`).hasClass("display-none"))
									$(`#${layerGroup[n].childs[m].replace(/ /g, "_")}_eye`).toggleClass("display-none");
                }
                $(this).toggleClass("display-none");
                $(this)
                  .parent()[0]
                  .children[3].classList.toggle("display-none");
								$("#studioDisableIcon").toggleClass("display-none");
            		$("#studioVisibleIcon").toggleClass("display-none");
              }
            }
          } else {
            map.setLayoutProperty(selectedLayer, "visibility", "visible");
            $(this).toggleClass("display-none");
            $(this).parent()[0].children[3].classList.toggle("display-none");
						$("#studioDisableIcon").toggleClass("display-none");
            $("#studioVisibleIcon").toggleClass("display-none");
						for (var n = 0; n < layerGroup.length; n++) {
							if (layerGroup[n].title === $(this).parent()[0].getAttribute("attrParent").replace(/_title/g, "")) {
								if (layerGroup[n].childs.length === 1) {
									$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_noeye`).toggleClass("display-none");
									$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_eye`).toggleClass("display-none");
								} else {
									var flag = false;
									for (var m = 0; m < layerGroup[n].childs.length; m++) {
										if (
											map.getLayoutProperty(
												layerGroup[n].childs[m],
												"visibility"
											) === "visible"
										) {
											flag = true;
										}
									}
									if (flag) {
										$("#studioVisibleIcon").addClass("display-none");
										$("#studioDisableIcon").removeClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_noeye`).removeClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_eye`).addClass("display-none");
									} else {
										$("#studioVisibleIcon").removeClass("display-none");
										$("#studioDisableIcon").addClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_noeye`).addClass("display-none");
										$(`#${layerGroup[n].title.replace(/ /g, "_")}_title_eye`).removeClass("display-none");
									}
								}								
							}
						}
          }
        });

        $("#studioMenuLayerEdit").on("click", "#studioRemoveIcon", function (
          e
        ) {
          e.preventDefault();
          e.stopPropagation();
          if ($("#studioMenuLayerEdit").hasClass("disabled")) return;
        });
      });
