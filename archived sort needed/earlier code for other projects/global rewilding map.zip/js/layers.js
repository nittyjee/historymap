      /////////////////////////////
      //MAP LAYERS
      /////////////////////////////


      map.on("load", function () {



        /////////////
        //BIODIVERSITY RICHNESS AND RARITY
        /////////////


        //GLOBAL FISHES RARITY
        map.addSource('Fishes Rarity', {
          type: 'vector',
          url: 'mapbox://nittyjee.36psb62s'
      });
        map.addLayer({
          'id': 'Fishes Rarity',
          'type': 'fill',
          'source': 'Fishes Rarity',
          'layout': {
              'visibility': 'visible'
          },

          "source-layer": "fishes_rarity-brnpau",

          paint: {
              "fill-color": {
                  property: "rarity",
                  type: "categorical",
                  stops: [
                      [1, "#0664f6"],
                      [2, "#2172db"],
                      [3, "#3d80bf"],
                      [4, "#588ea4"],
                      [5, "#749c89"],
                      [6, "#8fab6d"],
                      [7, "#abb952"],
                      [8, "#c6c737"],
                      [9, "#e2d51b"],
                      [10, "#fde300"]
                  ]
              }
          }

      });


        //GLOBAL FISHES RICHNESS
        map.addSource('Fishes Richness', {
          type: 'vector',
          url: 'mapbox://nittyjee.7d7iy9ij'
      });
        map.addLayer({
          'id': 'Fishes Richness',
          'type': 'fill',
          'source': 'Fishes Richness',
          'layout': {
              'visibility': 'visible'
          },

          "source-layer": "fishes_richness-59r4uj",

          paint: {
              "fill-color": {
                  property: "richness",
                  type: "categorical",
                  stops: [
                      [1, "#0664f6"],
                      [2, "#2172db"],
                      [3, "#3d80bf"],
                      [4, "#588ea4"],
                      [5, "#749c89"],
                      [6, "#8fab6d"],
                      [7, "#abb952"],
                      [8, "#c6c737"],
                      [9, "#e2d51b"],
                      [10, "#fde300"]
                  ]
              }
          }

      });


        //GLOBAL TURTLES RICHNESS
        map.addSource('Turtles Richness', {
          type: 'vector',
          url: 'mapbox://nittyjee.9dckm1fd'
      });
        map.addLayer({
          'id': 'Turtles Richness',
          'type': 'fill',
          'source': 'Turtles Richness',
          'layout': {
              'visibility': 'visible'
          },

          "source-layer": "turtles_richness-1a4uwx",

          paint: {
              "fill-color": {
                  property: "richTurt",
                  type: "categorical",
                  stops: [
                      [0, "rgba(0,0,0,0)"],
                      [1, "#0664f6"],
                      [2, "#2172db"],
                      [3, "#3d80bf"],
                      [4, "#588ea4"],
                      [5, "#749c89"],
                      [6, "#8fab6d"],
                      [7, "#abb952"],
                      [8, "#c6c737"],
                      [9, "#e2d51b"],
                      [10, "#fde300"]
                  ]
              }
          }

      });





      //EXCLUSIVE ECONOMIC ZONES (EEZ)

      //EEZ BOUNDARIES


        map.addSource("EEZ Boundaries", {
          type: "vector",
          url: "mapbox://nittyjee.bqod0jo6",
        });
        map.addLayer({
          id: "EEZ Boundaries",
          type: "line",
          source: "EEZ Boundaries",

          layout: {
            visibility: "visible",
          },

          "source-layer": "eez_boundaries-75ot0w",
          paint: {
            "line-color": "#000000",
            "line-opacity": 1
          }
        });



      //EEZ AREAS


      map.addSource("EEZ Areas", {
        type: "vector",
        url: "mapbox://nittyjee.cjfyo6pm",
      });
      map.addLayer({
        id: "EEZ Areas",
        type: "fill",
        source: "EEZ Areas",

        layout: {
          visibility: "visible",
        },

        "source-layer": "eez_shapes-7qz0yd",
        paint: {
          "fill-color": "#d3d3d3"
        }
      });







        /////////////
        //FOREST
        /////////////

        map.addSource("Forest Land", {
          type: "vector",
          url: "mapbox://nittyjee.5t66rftj",
        });
        map.addLayer({
          id: "Forest Land",
          type: "fill",
          source: "Forest Land",
          layout: {
            visibility: "visible",
          },

          "source-layer": "forest_all_iowa",

          paint: {
            "fill-color": "#5b9322",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //ALL CROPS
        /////////////

        map.addSource("Crops", {
          type: "vector",
          url: "mapbox://nittyjee.40faz9sy",
        });
        map.addLayer({
          id: "Crops",
          type: "fill",
          source: "Crops",
          layout: {
            visibility: "visible",
          },

          "source-layer": "all_crops_all_iowa",

          paint: {
            "fill-color": "#d0f0d2",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //ALL WATER
        /////////////

        map.addSource("Water", {
          type: "vector",
          url: "mapbox://nittyjee.absudjmp",
        });
        map.addLayer({
          id: "Water",
          type: "fill",
          source: "Water",
          layout: {
            visibility: "visible",
          },

          "source-layer": "water_all_iowa",

          paint: {
            "fill-color": "#363aba",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //WETLANDS
        /////////////

        map.addSource("Wetlands", {
          type: "vector",
          url: "mapbox://nittyjee.c4vtckr8",
        });
        map.addLayer({
          id: "Wetlands",
          type: "fill",
          source: "Wetlands",
          layout: {
            visibility: "visible",
          },

          "source-layer": "wetlands_all_iowa",

          paint: {
            "fill-color": "#65adc1",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //DEVELOPED
        /////////////

        map.addSource("Developed", {
          type: "vector",
          url: "mapbox://nittyjee.3yku7zdf",
        });
        map.addLayer({
          id: "Developed",
          type: "fill",
          source: "Developed",
          layout: {
            visibility: "visible",
          },

          "source-layer": "developed_all_iowa",

          paint: {
            "fill-color": "#000000",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //SHRUBLAND
        /////////////

        map.addSource("Shrubland", {
          type: "vector",
          url: "mapbox://nittyjee.9ooya6u3",
        });
        map.addLayer({
          id: "Shrubland",
          type: "fill",
          source: "Shrubland",
          layout: {
            visibility: "visible",
          },

          "source-layer": "shrubland_all_iowa",

          paint: {
            "fill-color": "#beb297",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //GRASSLAND AND PASTURE
        /////////////

        map.addSource("Grassland and Pasture", {
          type: "vector",
          url: "mapbox://nittyjee.agfuorgj",
        });
        map.addLayer({
          id: "Grassland and Pasture",
          type: "fill",
          source: "Grassland and Pasture",
          layout: {
            visibility: "visible",
          },

          "source-layer": "grassland_pasture_all_iowa",

          paint: {
            "fill-color": "#b2c34f",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.9, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //HAY
        /////////////

        map.addSource("Hay", {
          type: "vector",
          url: "mapbox://nittyjee.05xe7wt8",
        });
        map.addLayer({
          id: "Hay",
          type: "fill",
          source: "Hay",
          layout: {
            visibility: "visible",
          },

          "source-layer": "alfalfa_and_nonalflalfa_hay_all_iowa",

          paint: {
            "fill-color": "#e5b636",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [7.99, 0],
                [8.0, 1],
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //FLOODPLAINS
        /////////////

        /////////////
        //FLOODPLAIN, FEDERAL
        /////////////

        map.addSource("federal_25yr", {
          type: "vector",
          url: "mapbox://nittyjee.c1bl5si7",
        });
        map.addLayer({
          id: "federal_25yr",
          type: "fill",
          source: "federal_25yr",

          layout: {
            visibility: "visible",
          },

          "source-layer": "federal_25yr",
          paint: {
            "fill-color": "#dc3eaf",
            "fill-opacity": {
              stops: [
                [8, 0],
                [9, 1],

                /*May be more ideal:            
                            [7, 0],
                            [8, 1]
                            */
              ],
            },
          },
        });

        /////////////
        //FLOODPLAIN, IOWA FLOOD CENTER, 25-500YR
        /////////////

        map.addSource("IFC_Floodplain 25_500YR", {
          type: "vector",
          url: "mapbox://nittyjee.a3hreb9k",
        });
        map.addLayer({
          id: "IFC_Floodplain 25_500YR",
          type: "fill",
          source: "IFC_Floodplain 25_500YR",

          layout: {
            visibility: "visible",
          },

          "source-layer": "25_500",
          paint: {
            "fill-color": "#dc3eaf",
            "fill-opacity": {
              stops: [
                [8, 0],
                [9, 1],

                /*May be more ideal:            
                            [7, 0],
                            [8, 1]
                            */
              ],
            },
          },
        });

        /////////////
        //FLOODPLAIN, IOWA FLOOD CENTER, 25YR
        /////////////

        map.addSource("IFC_Floodplain", {
          type: "vector",
          url: "mapbox://nittyjee.24kmsjzg",
        });
        map.addLayer({
          id: "IFC_Floodplain",
          type: "fill",
          source: "IFC_Floodplain",

          layout: {
            visibility: "visible",
          },

          "source-layer": "ifc_25yr",
          paint: {
            "fill-color": "#dc9a00",
            "fill-opacity": {
              stops: [
                [8, 0],
                [9, 1],

                /*May be more ideal:            
                            [7, 0],
                            [8, 1]
                            */
              ],
            },
          },
        });

        /////////////
        //FLOODPLAIN, IOWA FLOOD CENTER, 5YR
        /////////////

        map.addSource("5yr", {
          type: "vector",
          url: "mapbox://nittyjee.buz7mlca",
        });
        map.addLayer({
          id: "5yr",
          type: "fill",
          source: "5yr",

          layout: {
            visibility: "visible",
          },

          "source-layer": "5yr",
          paint: {
            "fill-color": "#8ec7d3",
            "fill-opacity": {
              stops: [
                [8, 0],
                [9, 1],

                /*May be more ideal:            
                            [7, 0],
                            [8, 1]
                            */
              ],
            },
          },
        });

        /////////////
        //NONPRODUCTIVE LAND
        /////////////

        map.addSource("Cores", {
          type: "vector",
          url: "mapbox://nittyjee.8q3k2e1q",
        });
        map.addLayer({
          id: "Rewilding Priority Land Cover (RPLC)",
          type: "fill",
          source: "Cores",
          layout: {
            visibility: "visible",
          },

          "source-layer": "nonprod",

          paint: {
            "fill-color": {
              property: "acres",
              stops: [
                [0, "#b5de93"],
                [9999, "#b5de93"],
                [10000, "#82cd4f"],
                [1000000, "#82cd4f"],
              ],
            },

            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.21, 1],
                /*
                            [5.7, 1],
                            [5.71, 0],
                            [7.9,0],
                            
                            [8.0,1],
                            */
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });

        /////////////
        //NONPRODUCTIVE LAND WITH FLOODPLAINS
        /////////////

        map.addSource("Cores With Floodplains", {
          type: "vector",
          url: "mapbox://nittyjee.dawues7i",
        });
        map.addLayer({
          id: "RPLF: Rewilding Priority Land with Floodplains",
          type: "fill",
          source: "Cores With Floodplains",
          layout: {
            visibility: "visible",
          },

          "source-layer": "nonprod_floodplains",

          paint: {
            "fill-color": {
              property: "acres",
              stops: [
                [0, "#b5de93"],
                [9999, "#b5de93"],
                [10000, "#82cd4f"],
                [1000000, "#82cd4f"],
              ],
            },

            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.21, 1],
                /*
                            [5.7, 1],
                            [5.71, 0],
                            [7.9,0],
                            
                            [8.0,1],
                            */
                [11.6, 1],
                [12.3, 0],
              ],
            },
          },
        });


        /////////////
        //NONPRODUCTIVE LAND QUADS
        /////////////

        map.addSource('Cores Quads', {
            type: 'vector',
            url: 'mapbox://nittyjee.ay6ojc2k'
        });
        map.addLayer({
                'id': 'Cores Quads',
                'type': 'fill',
                'source': 'Cores Quads',
                'layout': {
                    'visibility': 'none'
                },

                "source-layer": "nonprod_quad",

                paint: {

                    'fill-color': {
                        property: '2_5_mill',
                        type: 'categorical',
                        stops: [
                            ['0', '#ffffff'],
                            ['1', '#82cd4f']
                        ]
                    },

                    "fill-opacity": {
                        stops: [
                            [5.2, 0],
                            [5.21, 1],
                            /*
                            [5.7, 1],
                            [5.71, 0],
                            [7.9,0],
                            
                            [8.0,1],
                            */
                            [11.6, 1],
                            [12.3, 0]
                        ]
                    }

                }

            });

        /////////////
        //NONPRODUCTIVE LAND WITH FLOODPLAINS
        /////////////

        map.addLayer({
          id: "Cores With Floodplains Hover",
          type: "fill",
          source: "Cores With Floodplains",

          layout: {
            visibility: "visible",
          },
          paint: {
            "fill-color": "#000000",
            "fill-opacity": [
              "case",
              ["boolean", ["feature-state", "hover"], false],
              1,
              0,
            ],
          },
        });

        /////////////
        //LELAND OUTSIDE IOWA LINES
        /////////////

        map.addSource("Leland Outside Iowa Lines", {
          type: "vector",
          url: "mapbox://nittyjee.byknmy4i",
        });
        map.addLayer({
          id: "Leland Outside Iowa Lines",
          type: "line",
          source: "Leland Outside Iowa Lines",

          layout: {
            visibility: "visible",
          },

          "source-layer": "leland_outside_lines-6v6ftu",
          paint: {
            "line-color": "#b5d076",
            "line-opacity": {
              stops: [
                [4, 0],
                [5, 1],
              ],
            },
          },
        });

        /////////////
        //LELAND MISSOURI
        /////////////

        map.addSource("Leland Missouri", {
          type: "vector",
          url: "mapbox://nittyjee.4nrj6b38",
        });
        map.addLayer({
          id: "Leland Missouri",
          type: "fill",
          source: "Leland Missouri",

          layout: {
            visibility: "visible",
          },

          "source-layer": "leland_missouri-c6jz6o",
          paint: {
            "fill-color": "#82cd4f",
            "fill-opacity": {
              stops: [
                [5, 0],
                [5.2, 1],
              ],
            },
          },
        });

        /////////////
        //LELAND OUTSIDE
        /////////////

        map.addSource("Leland Outside Iowa", {
          type: "vector",
          url: "mapbox://nittyjee.5fx5p117",
        });
        map.addLayer({
          id: "Leland Outside Iowa",
          type: "fill",
          source: "Leland Outside Iowa",

          layout: {
            visibility: "visible",
          },

          "source-layer": "leland_outside-db61ef",
          paint: {
            "fill-color": "#82cd4f",
            "fill-opacity": {
              stops: [
                [4, 0],
                [4.5, 1],
              ],
            },
          },
        });

        /////////////
        //LELAND LOESS HILLS ADDITION
        /////////////

        map.addSource("Leland Loess Hills Addition", {
          type: "vector",
          url: "mapbox://nittyjee.crvajd16",
        });
        map.addLayer({
          id: "Leland Loess Hills Addition",
          type: "fill",
          source: "Leland Loess Hills Addition",

          layout: {
            visibility: "visible",
          },

          "source-layer": "loess_hills_addition_leland-1686l5",
          paint: {
            "fill-color": "#82cd4f",
            "fill-opacity": {
              stops: [
                [5, 0],
                [5.2, 1],
              ],
            },
          },
        });

        /////////////
        //LELAND OUTSIDE LABELS
        /////////////

        map.addSource("Leland Outside Labels", {
          type: "vector",
          url: "mapbox://nittyjee.admkqgei",
        });

        map.addLayer({
          id: "Leland Outside Labels",
          type: "symbol",
          source: "Leland Outside Labels",

          layout: {
            visibility: "visible",
          },

          layout: {
            "text-field": "{Name}",
            "text-size": {
              stops: [
                [11, 10],
                [12, 12],
              ],
            },
          },

          "source-layer": "leland_outside-d8mcrt",

          paint: {
            "text-halo-color": "#ffffff",
            "text-halo-width": 5,
            "text-opacity": {
              stops: [
                [8, 0],
                [9, 1],
              ],
            },
          },
        });

        /////////////
        //LELAND LOESS HILLS ADDITION LABELS
        /////////////

        map.addSource("Leland Loess Hills Addition Labels", {
          type: "vector",
          url: "mapbox://nittyjee.59lf97l3",
        });

        map.addLayer({
          id: "Leland Loess Hills Addition Labels",
          type: "symbol",
          source: "Leland Loess Hills Addition Labels",

          layout: {
            visibility: "visible",
          },

          layout: {
            "text-field": "{Name}",
            "text-size": {
              stops: [
                [11, 10],
                [12, 12],
              ],
            },
          },

          "source-layer": "labels_loess_hills_addition_l-336ghn",

          paint: {
            "text-halo-color": "#ffffff",
            "text-halo-width": 5,
            "text-opacity": {
              stops: [
                [8, 0],
                [9, 1],
              ],
            },
          },
        });

        /////////////
        //LELAND MISSOURI LABELS
        /////////////

        map.addSource("Leland Missouri Labels", {
          type: "vector",
          url: "mapbox://nittyjee.5akfbq8u",
        });

        map.addLayer({
          id: "Leland Missouri Labels",
          type: "symbol",
          source: "Leland Missouri Labels",

          layout: {
            visibility: "visible",
          },

          layout: {
            "text-field": "{Name}",
            "text-size": {
              stops: [
                [11, 10],
                [12, 12],
              ],
            },
          },

          "source-layer": "leland_missouri-6g31p3",

          paint: {
            "text-halo-color": "#ffffff",
            "text-halo-width": 5,
            "text-opacity": {
              stops: [
                [8, 0],
                [9, 1],
              ],
            },
          },
        });


        /////////////
        //Main Corridor lines
        /////////////

        map.addSource("Main Corridor lines", {
          type: "vector",
          url: "mapbox://nittyjee.52y1zcpp",
        });
        map.addLayer({
          id: "Main Corridor lines",
          type: "line",
          source: "Main Corridor lines",
          layout: {
            visibility: "visible",
          },

          "source-layer": "main_corridor_lines",

          paint: {
            "line-color": {
              property: "notes3",
              type: "categorical",
              stops: [
                ["new", "#d5b43c"],
                ["between", "#f41b1b"],
                ["alternate", "#e57f36"],
                ["edge", "#ecde3e"],
                //["Anti-Mason", "rgba(204,255,230,1)"]
              ],
            },

            "line-width": 3,

            "line-opacity": {
              stops: [
                [4, 0],
                [4.3, 1],
              ],
            },
          },
        });































































        /////////////
        //DNR CORES
        /////////////

        map.addSource("DNR Cores", {
          type: "vector",
          url: "mapbox://nittyjee.ditotwj2",
        });
        map.addLayer({
          id: "DNR Cores",
          type: "fill",
          source: "DNR Cores",

          layout: {
            visibility: "visible",
          },

          "source-layer": "dnr_cores-ad58ei",
          paint: {
            "fill-color": "#b5d076",
            "fill-opacity": {
              stops: [
                [4, 0],
                [5, 1],
              ],
            },
          },
        });

        /////////////
        //WATERBODIES AREAS ALL IOWA
        /////////////

        map.addSource("Waterbodies Areas All Iowa", {
          type: "vector",
          url: "mapbox://nittyjee.75342z2p",
        });
        map.addLayer({
          id: "Waterbodies",
          type: "fill",
          source: "Waterbodies Areas All Iowa",
          layout: {
            visibility: "visible",
          },
          "source-layer": "waterbodies_areas_all_iowa",
          paint: {
            "fill-color": "#2e75a8",
            "fill-opacity": {
              stops: [
                [8, 0],
                [9, 1],
              ],
            },
          },
        });



        /////////////
        //CORE LINES
        /////////////

        map.addSource("Core Lines", {
          type: "vector",
          url: "mapbox://nittyjee.6ql0leis",
        });
        map.addLayer({
          id: "Core Lines",

          type: "line",

          source: "Core Lines",
          layout: {
            visibility: "visible",
          },

          "source-layer": "lines_all_leland_2",

          paint: {
            "line-color": "#454f36",
            "line-opacity": {
              stops: [
                [9.5, 0],
                [10, 1],
              ],
            },
          },
        });

        ///////////////////////////////////////
        //IOWA RIVER WATERSHED LAYERS
        ///////////////////////////////////////

        /////////////
        //CORE SHAPES
        /////////////

        map.addSource("Iowa River Cores", {
          type: "vector",
          url: "mapbox://nittyjee.7qr1p86q",
        });
        map.addLayer({
          id: "Iowa River Cores",

          type: "fill",

          source: "Iowa River Cores",
          layout: {
            visibility: "visible",
          },

          "source-layer": "all_core_shapes",

          paint: {
            "fill-color": "#c8dd97",
            "fill-opacity": 1.0,
          },
        });



        /////////////
        //CORE LINES
        /////////////

        map.addSource("Iowa River Core Lines", {
          type: "vector",
          url: "mapbox://nittyjee.60ncl9ld",
        });
        map.addLayer({
          id: "Iowa River Core Lines",
          type: "line",
          source: "Iowa River Core Lines",

          layout: {
            visibility: "visible",
          },

          "source-layer": "all_core_shapes_lines",

          paint: {
            "line-color": "#606e49",
            "line-opacity": 1.0,
          },
        });

        ///////////////////////////////////////
        //MISSISSIPPI RIVER WATERSHED LAYERS
        ///////////////////////////////////////

        ///////////////////////
        //DRAINAGE AREA: 10,000
        ///////////////////////

        map.addSource("Mississippi 10000", {
          type: "vector",
          url: "mapbox://nittyjee.5uheqxwp",
        });
        map.addLayer({
          id: "Mississippi 10000",
          type: "line",
          source: "Mississippi 10000",

          layout: {
            visibility: "visible",
          },

          "source-layer": "10000",

          paint: {
            "line-color": "#1496fa",
            "line-opacity": 0.5,
          },
        });

        ///////////////////////
        //DRAINAGE AREA: 2,500
        ///////////////////////

        map.addSource("Mississippi 2500", {
          type: "vector",
          url: "mapbox://nittyjee.2x0hal6u",
        });
        map.addLayer({
          id: "Mississippi 2500",
          type: "line",
          source: "Mississippi 2500",

          layout: {
            visibility: "visible",
          },

          "source-layer": "2500",

          paint: {
            "line-color": "#1496fa",
            "line-opacity": {
              stops: [
                [3, 0],
                [4, 1],
                [4.99, 1],
                [5, 0],
              ],
            },
          },
        });

        ///////////////////////
        //DRAINAGE AREA: 1,000
        ///////////////////////

        map.addSource("Mississippi 1000", {
          type: "vector",
          url: "mapbox://nittyjee.1a2hsx4i",
        });
        map.addLayer({
          id: "Mississippi 1000",
          type: "line",
          source: "Mississippi 1000",

          layout: {
            visibility: "visible",
          },

          "source-layer": "1000",

          paint: {
            "line-color": "#1496fa",
            "line-opacity": {
              stops: [
                [4, 0],
                [5, 1],
                [6.99, 1],
                [7, 0],
              ],
            },
          },
        });

        ///////////////////////
        //DRAINAGE AREA: 100
        ///////////////////////

        map.addSource("Mississippi 100", {
          type: "vector",
          url: "mapbox://nittyjee.91ny3dku",
        });
        map.addLayer({
          id: "Mississippi 100",
          type: "line",
          source: "Mississippi 100",

          layout: {
            visibility: "visible",
          },

          "source-layer": "100",

          paint: {
            "line-color": "#1496fa",
            "line-opacity": {
              stops: [
                [5, 0],
                [5.4, 0.04],
                [6, 0.17],
                [6.5, 0.7],
                [7, 1],
                [11.99, 1],
                [12, 0],
              ],
            },
          },
        });

        ///////////////////////
        //DRAINAGE AREA: ALL FLOWLINES
        ///////////////////////

        map.addSource("Mississippi All Flowlines", {
          type: "vector",
          url: "mapbox://nittyjee.9ventf03",
        });
        map.addLayer({
          id: "Mississippi All Flowlines",
          type: "line",
          source: "Mississippi All Flowlines",

          layout: {
            visibility: "visible",
          },

          "source-layer": "all_flowlines",

          paint: {
            "line-color": "#1496fa",
            "line-opacity": {
              stops: [
                [7.5, 0],
                [8.5, 0.1],
                [10, 0.35],
                [12, 1],
              ],
            },
          },
        });

        ///////////////////////////////////////
        //CORE LABELS
        ///////////////////////////////////////

        map.addSource("Core Labels", {
          type: "vector",
          url: "mapbox://nittyjee.amihpzcx",
        });

        map.addLayer({
          id: "Core Labels",
          type: "symbol",
          source: "Core Labels",

          layout: {
            visibility: "visible",
          },

          layout: {
            "text-field": "{Name}",
            "text-size": {
              stops: [
                [11, 10],
                [12, 12],
              ],
            },
          },

          "source-layer": "core_labels_11-dakmab",

          paint: {
            "text-halo-color": "#ffffff",
            "text-halo-width": 5,
            "text-opacity": {
              stops: [
                [11, 0],
                [11.5, 1],
              ],
            },
          },
        });

        /////////////
        //CORRIDORS
        /////////////

        map.addSource("Corridors", {
          type: "vector",
          url: "mapbox://nittyjee.4uit2ga3",
        });
        map.addLayer({
          id: "Corridors",
          type: "line",
          source: "Corridors",
          layout: {
            visibility: "visible",
          },

          "source-layer": "corridors_all_iowa",

          paint: {
            "line-color": "#000000",
            "line-opacity": {
              stops: [
                [8, 0],
                [9, 1],
              ],
            },
          },
        });

        /////////////
        //CITY LIMITS
        /////////////

        /////////////
        //CITY LIMITS, 1 MILE BOUNDARY
        /////////////

        map.addSource("City Limits 1 Mile Boundary", {
          type: "vector",
          url: "mapbox://nittyjee.33tkjkbf",
        });
        map.addLayer({
          id: "City Limits 1 Mile Boundary",
          type: "fill",
          source: "City Limits 1 Mile Boundary",
          layout: {
            visibility: "visible",
          },

          "source-layer": "city_limits_1mi",

          paint: {
            "fill-color": "rgba(255,255,255,1)",
            "fill-outline-color": "rgba(0,0,0,0.4)",
            "fill-opacity": {
              stops: [
                [5.2, 0],
                [5.7, 1],
                [5.71, 0],
                [6.2, 0],
                [6.3, 1],
              ],
            },
          },
        });

        /////////////
        //CITY LIMITS
        /////////////

        map.addSource("City Limits", {
          type: "vector",
          url: "mapbox://nittyjee.21bfq5za",
        });
        map.addLayer({
          id: "City Limits",
          type: "fill",
          source: "City Limits",
          layout: {
            visibility: "visible",
          },

          "source-layer": "city_limits",

          paint: {
            "fill-color": "rgba(255,255,255,1)",
            "fill-outline-color": "rgba(0,0,0,1)",
            "fill-opacity": {
              stops: [
                [8.5, 0],
                [8.51, 1],
              ],
            },
          },
        });
		
		
            /////////////
            //BRIDGES
            /////////////


            map.addSource('Bridges', {
                type: 'vector',
                url: 'mapbox://nittyjee.6wejn55b'
            });


            map.addLayer({
                'id': 'Bridges',
                'type': 'circle',
                'source': 'Bridges',

                'layout': {
                    'visibility': 'none'
                },
                "source-layer": "bridges_merged-91btjj",

                paint: {
                    'circle-color': '#6a0dad',
                    'circle-radius': {
                        stops: [
                            [6, 3],
                            [10, 3],
                            [11, 5]
                        ]
                    },

                    "circle-opacity": {
                        stops: [
                            [9.5, 0],
                            [10.5, 1]
                        ]
                    }


                }




            });


            /////////////
            //QUADRANTS
            /////////////

            map.addSource('Quadrants', {
                type: 'vector',
                url: 'mapbox://nittyjee.5pqgwwgi'
            });
            map.addLayer({
                'id': 'Quadrants',
                'type': 'line',
                'source': 'Quadrants',
                'layout': {
                    'visibility': 'none'
                },

                "source-layer": "iowa_quads-a47f41",

                paint: {
                    "line-width": 2.0,
                    "line-opacity": {
                        stops: [
                            [5.2, 0],
                            [5.21, 1]
                        ]
                    }

                }

            });
		
		
            /////////////
            //SE Quadrant
            /////////////

            map.addSource('SE Quadrant', {
                type: 'vector',
                url: 'mapbox://nittyjee.1mxudmx5'
            });
            map.addLayer({
                'id': 'SE Quadrant',
                'type': 'line',
                'source': 'SE Quadrant',
                'layout': {
                    'visibility': 'none'
                },

                "source-layer": "se_watershed_quadrant-3rjkzx",

                paint: {
                    "line-color": "#ff0000",
                    "line-width": 3.0,
                    "line-opacity": {
                        stops: [
                            [5.2, 0],
                            [5.21, 1]
                        ]
                    }

                }

            });
    

            /////////////
            //Landform Regions
            /////////////

            map.addSource('Landform Regions', {
                type: 'vector',
                url: 'mapbox://nittyjee.4ke8xij7'
            });
            map.addLayer({
                'id': 'Landform Regions',
                'type': 'line',
                'source': 'Landform Regions',
                'layout': {
                    'visibility': 'none'
                },

                "source-layer": "landform_regions-7pxy63",

                paint: {
                    "line-color": "#000000",
                    "line-width": 2.0,
                    "line-opacity": {
                        stops: [
                            [5.2, 0],
                            [5.21, 1]
                        ]
                    }

                }

            });
		

        });



      ///////////////////////
      //END LAYERS
      ///////////////////////















        ///////////////////////////////////////////////
        //USED FOR HOVERING AND HIGHLIGHTING
        //CORES WITH FLOODPLAINS
        //UNUSED
        //MOVED TO BOTTOM, MAY NEED TO MOVE ELSEWHERE.
        //REFER TO ORIGINAL REWILDING MAP.
        ///////////////////////////////////////////////


        // When the user moves their mouse over the state-fill layer, we'll update the
        // feature state for the feature under the mouse.
        map.on("mousemove", "Cores With Floodplains Hover", function (e) {
          if (e.features.length > 0) {
            if (hoveredStateId) {
              map.setFeatureState(
                { source: "Cores With Floodplains", id: hoveredStateId },
                { hover: false }
              );
            }
            hoveredStateId = e.features[0].id;
            map.setFeatureState(
              { source: "Cores With Floodplains", id: hoveredStateId },
              { hover: true }
            );
          }
        });

        // When the mouse leaves the state-fill layer, update the feature state of the
        // previously hovered feature.
        map.on("mouseleave", "Cores With Floodplains Hover", function () {
          if (hoveredStateId) {
            map.setFeatureState(
              { source: "Cores With Floodplains", id: hoveredStateId },
              { hover: false }
            );
          }
          hoveredStateId = null;
        });






