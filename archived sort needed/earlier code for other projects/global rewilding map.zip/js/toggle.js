    /////////////////////////////
    //LAYERS AND TOGGLE LEGEND FUNCTIONS
    /////////////////////////////

    function setLayers() {
      //TOGGLE LAYERS

      var toggleableLayerIdsChecked = [];

      var toggleableLayerIdsUnchecked = [];

      //LEGEND
      var toggleLegend = document.getElementById("toggleLegend");
      while (toggleLegend.hasChildNodes()) {
        toggleLegend.removeChild(toggleLegend.lastChild);
      }

      //TOGGLING CHECKED
      for (var i = 0; i < toggleableLayerIdsChecked.length; i++) {
        //use closure to deal with scoping
        (function () {
          var id = toggleableLayerIdsChecked[i];

          //CHECKBOX
          var input = document.createElement("input");
          input.type = "checkbox";
          input.id = id;
          input.checked = true;

          //LABEL
          var label = document.createElement("label");
          label.setAttribute("for", id);
          label.textContent = id;

          //VISIBILITY (CHECKED VS. UNCHECKED)
          input.addEventListener("change", function (e) {
            map.setLayoutProperty(
              id,
              "visibility",
              e.target.checked ? "visible" : "none"
            );
          });

          //NOTE?
          var layers = document.getElementById("toggleLegend");
          layers.appendChild(input);
          layers.appendChild(label);
          layers.appendChild(document.createElement("br"));
        })();
      }

      //TOGGLING UNCHECKED
      for (var i = 0; i < toggleableLayerIdsUnchecked.length; i++) {
        //use closure to deal with scoping
        (function () {
          var id = toggleableLayerIdsUnchecked[i];

          //CHECKBOX
          var input = document.createElement("input");
          input.type = "checkbox";
          input.id = id;
          input.checked = false;

          //LABEL
          var label = document.createElement("label");
          label.setAttribute("for", id);
          label.textContent = id;

          //VISIBILITY (CHECKED VS. UNCHECKED)
          input.addEventListener("change", function (e) {
            map.setLayoutProperty(
              id,
              "visibility",
              e.target.checked ? "visible" : "none"
            );
          });

          //NOTE?
          var layers = document.getElementById("toggleLegend");
          layers.appendChild(input);
          layers.appendChild(label);
          layers.appendChild(document.createElement("br"));
        })();
      }
    }

    //LAYER SWITCHING
    function switchStyle() {
      var basemaps = document.getElementById("styleSwitcher");
      var inputs = basemaps.getElementsByTagName("input");
      console.log(inputs);
      console.log(inputs.length);

      for (var i = 0; i < inputs.length; i++) {
        inputs[i].onclick = switchLayer;
      }
    }