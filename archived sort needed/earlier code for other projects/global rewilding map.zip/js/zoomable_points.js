      /////////////////////////////
      //ZOOMABLE POINTS
      /////////////////////////////

      function addLayers() {
        map.on("load", function () {
          var lbl_color = "#482525";
          var lbl_color_hover = "#ff0000";
          var cities = ["iowariver"];

          map.addLayer({
            id: "places-iowariver",
            type: "symbol",
            source: {
              type: "geojson",
              data: {
                type: "FeatureCollection",
                features: [
                  {
                    type: "Feature",
                    properties: {
                      title: "Iowa",
                      icon: "circle",
                      bounds: [
                        [-96.504, 43.7],
                        [-90.37, 40.2],
                      ],
                    },
                    geometry: {
                      type: "Point",
                      coordinates: [-93.0977, 41.878],
                      /*
                                    north: 43.213/-93.644
                                    south: 40.482/-93.502
                                    east: 41.795/-90.37
                                    west: 42.436/-96.504
*/
                    },
                  },
                ],
              },
            },
            layout: {
              "text-font": ["Open Sans Regular"],
              "text-field": "{title}",
              "text-size": 18,
              //"text-anchor": "center"
            },
            paint: {
              "text-color": lbl_color,
              "text-halo-width": 6,
              "text-halo-color": "#ffffff",
            },
          });

          var map_city_click = function (e) {
            if ((feature = getRenderedFeature(e.point))) {
              var bounds = JSON.parse(feature.properties.bounds);

              map.fitBounds(bounds, {
                padding: {
                  top: 10,
                  bottom: 25,
                  left: 15,
                  right: 5,
                },
              });
            }
          };

          map.on("click", map_city_click);

          map.on("mousemove", function (e) {
            if ((feature = getRenderedFeature(e.point))) {
              layer = feature.layer.id;
              map.setPaintProperty(layer, "text-color", lbl_color_hover);
              map.getCanvas().style.cursor = "pointer";
            } else {
              map.setPaintProperty("places-iowariver", "text-color", lbl_color);
              map.getCanvas().style.cursor = "";
            }
          });

          function getRenderedFeature(point) {
            var width = 50;
            var height = 14;
            var feature = map.queryRenderedFeatures(
              [
                [point.x - width / 2, point.y - height * 0.9],
                [point.x + width / 2, point.y + height * 0.1],
              ],
              {
                layers: ["places-iowariver"],
              }
            )[0];

            if (typeof feature != "undefined") {
              return feature;
            } else {
              return 0;
            }
          }
        });
      }

