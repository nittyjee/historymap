
            map.on("load", function () {


                ////////////////////////////////
                //TOGGLE LAYERS AND TITLES
                ///////////////////////////////

                
                //BIODIVERSITY RICHNESS AND RARITY
                toggleLayer(
                  ["Fishes Rarity", "Fishes Richness", "Turtles Richness"],
                  "Biodiversity Richness and Rarity",
                  false
                );


                //EXCLUSIVE ECONOMIC ZONES (EEZ)
                toggleLayer(
                  ["EEZ Boundaries", "EEZ Areas"],
                  "Exclusive Economic Zones (EEZ)",
                  false
                );
                

                //RPLC
                toggleLayer(["Rewilding Priority Land Cover (RPLC)"], "Rewilding Priority Land Cover (RPLC)", false);
        
                //RPLF
                toggleLayer(["RPLF: Rewilding Priority Land with Floodplains"], "RPLF: Rewilding Priority Land with Floodplains");


        
                //CORES
                toggleLayer(
                  [
                  "Core Labels",
                    "Core Lines",
                    "Iowa River Core Lines",
                    "DNR Cores",
                    //"Leland Outside Iowa Lines",
                    "Leland Missouri",
                    "Leland Outside Iowa",
                    "Leland Outside Labels",
                    "Leland Missouri Labels",
                    "Leland Outside Iowa Lines",
                    "Leland Loess Hills Addition",
                    "Leland Loess Hills Addition Labels",
                  ],
                  "Cores",
                  true, // view layer ( if false, then apply visible:none )
                  false // expand drop down
                );
        
                //FLOWLINES
                toggleLayer(
                  [
                    "Mississippi 10000",
                    "Mississippi 2500",
                    "Mississippi 1000",
                    "Mississippi 100",
                    "Mississippi All Flowlines",
                  ],
                  "Flowlines",
                  true, // view layer ( if false, then apply visible:none )
                  false // expand drop down
                );
        
                //CITY LIMITS
                toggleLayer(
                  ["City Limits", "City Limits 1 Mile Boundary"],
                  "City Limits",
                  true, // view layer ( if false, then apply visible:none )
                      false // expand drop down
                );
                
                //CORRIDORS
                toggleLayer(["Corridors"], "Corridors");
        
                //WATERBODIES
                toggleLayer(["Waterbodies"], "Waterbodies");
                
                //BRIDGES
                toggleLayer(["Bridges"], "Bridges", false);
                  
                //FLOODPLAINS
                toggleLayer(
                  [
                    "IFC_Floodplain",
                    "5yr",
                    "IFC_Floodplain 25_500YR",
                    "federal_25yr"
                  ],
                  "Floodplains",
                  false, // view layer ( if false, then apply visible:none )
                  false // expand drop down
                );
        
        
        
                //LAND COVER LAYERS
                toggleLayer(
                  [
                    "Forest Land",
                    "Water",
                    "Wetlands",
                    "Developed",
                    "Shrubland",
                    "Crops",
                    "Grassland and Pasture",
                    "Hay"
                  ],
                  "Land Cover Layers",
                  false, // view layer ( if false, then apply visible:none )
                  false // expand drop down
                );
        
                //REGIONS
                toggleLayer(
                  [
                    "Quadrants",
                    "SE Quadrant",
                    "Landform Regions",
                    "Cores Quads"
                  ],
                  "Regions",
                   false,
                   false
                );
        
                //CORES QUADS
                //toggleLayer(["Cores Quads"], "Cores Quads", false);
        
        

                
                function toggleLayer(ids, name, activeLayer = true, expandLayer = true) {
                  layerGroup.push({
                    title: name,
                    childs: ids,
                  });
             
                  var eyeEnTxt = "display-none";
                  var noeyeEnTxt = "";
                  
                  var caretPos = "caret-down";
                  var nestedActive = "active";
                  
                  if(!expandLayer){
                      caretPos = "";
                      nestedActive = "";
                  }
                  
                  if(!activeLayer){
                      eyeEnTxt = "";
                      noeyeEnTxt = "display-none";
                  }
                  
                  
                  console.log(ids.length);
                  console.log(name);
             
                  // Add to studio menu
                  var dom = `
                                <li>
                            `;
                  if(ids.length > 1) {
                     dom += `
                                    <div class="studio-layer-tile" attrName="${name}_title">
                                        <span class="caret ${caretPos}"></span>
                                        <span>
                                                <svg id="icon-folder" viewBox="0 0 18 18" style="width:15px"><path d="M4 7h10V6s0-1-1-1h-3C9 5 9 4 8 4H5C4 4 4 5 4 5v2zm0 1v5s0 1 1 1h8c1 0 1-1 1-1V8H4z"></path></svg>
                                        </span>
                                        <span class="layer-menu" attrName="${name}_title">${name}</span>
                                        
                                        <span class="studio-layer-icon ${noeyeEnTxt} icon-noeye" id="${name.replace(/ /g, "_")}_title_noeye">
                                            <svg viewBox="0 0 18 18">
                                                <path	
                                                    d="M8 4C4 4 2 9 2 9s2 4 6 4h2c4 0 6-4 6-4s-2-5-6-5H8zM6 6.6V7c0 1.2.8 2.3 1.8 2.8h.1c.2.1.3.1.5.2H9c.4 0 .8-.1 1.2-.2 1-.5 1.8-1.6 1.8-2.8v-.4c1.5.9 2 2.4 2 2.4s-2 2.5-4 2.5H8C6 11.5 4 9 4 9s.6-1.5 2-2.4z"
                                                ></path>
                                            </svg>
                                        </span>
                                        <span class="studio-layer-icon ${eyeEnTxt} icon-eye" id="${name.replace(/ /g, "_")}_title_eye">
                                            <svg viewBox="0 0 18 18">
                                                <path
                                                    d="M4 10s.6-1.5 2-2.4c0 0 1.1-.6 2-.8L9.6 5H8c-4 0-6 5-6 5s.6 1.1 1.7 2.1c.1-.3.2-.5.4-.8l.6-.7c-.4-.3-.7-.6-.7-.6zM11.9 5h-.1c-.2 0-.4.2-.6.3l-6 7c-.4.4-.4 1.1 0 1.5s1.1.3 1.5-.2l6-7c.6-.5 0-1.7-.8-1.6zM14.2 7.2c-.1.2-.2.3-.3.4l-.8.9c.6.8.9 1.5.9 1.5s-2 2.5-4 2.5h-.3L8.4 14H10c4 0 6-4 6-4s-.6-1.5-1.8-2.8z"
                                                ></path>
                                            </svg>
                                        </span>
                        
                                        
                                        <span class="info-icon" id="${name.replace(/ /g, "_")}_title_info">
                                            <svg viewBox="0 0 24 24">
                                                <path	
                                                    d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"
                                                ></path>
                                            </svg>
                                        </span>
                                        
                                    </div>
                                    
                                        
                                        
                                    <div class="nested ${nestedActive}">
                                `;
                  }
                  
                  for (i in ids) {
                  
                    map.setLayoutProperty(
                        ids[i],
                        "visibility",
                         activeLayer ? "visible" : "none"
                      );
                  
                    const layer = map.getLayer(ids[i]);
                    var icon = "",
                      color = "";
                    switch (layer.type) {
                      case "fill":
                        icon = `<svg id="icon-fill" viewBox="0 0 18 18" style="width:20px;margin-right:3px"><path d="M7 5c-.4 0-.7.2-.9.6l-3 6c-.3.6.2 1.4.9 1.4h10c.7 0 1.2-.8.9-1.4l-3-6c-.2-.4-.5-.6-.9-.6H7z"></path></svg>`;
                        color = map.getPaintProperty(ids[i], "fill-color");
                        break;
                      case "line":
                        icon = `<svg id="icon-line" viewBox="0 0 18 18" style="width:20px;margin-right:3px"><path d="M4.5 11.5l7-7c1.5-1.5 3.5.5 2 2l-7 7C5 15 3 13 4.5 11.5z"></path></svg>`;
                        color = map.getPaintProperty(ids[i], "line-color");
                        break;
                      case "symbol":
                        icon = `<svg id="icon-transform-uppercase" viewBox="0 0 18 18" style="width:20px;margin-right:3px"><path d="M13 5c0 1-1 1-1 1h-2v7s0 1-1 1-1-1-1-1V6H6S5 6 5 5s1-1 1-1h6s1 0 1 1z"></path></svg>`;
                        color = map.getPaintProperty(ids[i], "text-color");
                        break;
                      case "circle":
                        icon = `<svg id="icon-circle" viewBox="0 0 18 18" style="width:20px;margin-right:3px"><path d="M14 9c0 2.8-2.2 5-5 5s-5-2.2-5-5 2.2-5 5-5 5 2.2 5 5z"></path></svg>`;
                        color = map.getPaintProperty(ids[i], "circle-color");
                        break;
                      default:
                        icon = `<svg id="icon-fill" viewBox="0 0 18 18" style="width:20px;margin-right:3px;"><path d="M7 5c-.4 0-.7.2-.9.6l-3 6c-.3.6.2 1.4.9 1.4h10c.7 0 1.2-.8.9-1.4l-3-6c-.2-.4-.5-.6-.9-.6H7z"></path></svg>`;
                        color = map.getPaintProperty(ids[i], "fill-color");
                    }
                    
                    var multClr = false;
                    var clrs = [];
                    
                    //if(ids[i] == "Cores") {
                    //console.log(ids[i]);
                    //console.log(color);
                    //console.log(map.getPaintProperty(ids[i], "fill-color"));
                    //console.log(color.stops);
                    if ( !( typeof color === "undefined" ) ) {
                        if (typeof color.stops === "undefined" )
                            multClr = false;
                        else {
                            multClr = true;
                            for (var k = 0; k < color.stops.length; k++) {
                                var clrAbsent = true;
                                for (var j = 0; j < clrs.length; j++) {
                                   if(color.stops[k][1] == clrs[j] ) clrAbsent = false;
                                }
                                if(clrAbsent)
                                    clrs.push(color.stops[k][1]);
                            }
                            //console.log(clrs);
                        }
                    }
                    //console.log(layer.type + " <> " + ( multClr ? " multiple colors " : " single colors " ));
                    //}
                    var mulClrCont = ``;
                    if(multClr) {
                        for (var j = 0; j < clrs.length; j++) {
                          mulClrCont += `<div class="w100 h100" style="background:${clrs[j]}"></div>`;
                        }
                        layerColors.push({layerName: ids[i], colors: clrs });
                        
                    } else {
                        layerColors.push({layerName: ids[i], colors: [color] })
                    }
        
                    if(ids.length > 1) {
                        dom += `
                                    <div class="studio-layer-tile" attrName="${ids[i]}" attrParent="${name}_title">
                                        <div class="fill-canvas ml10 flex-no-shrink">` +
                                                ( multClr ? mulClrCont  : `<div class="w100 h100" style="background:${color}"></div>` ) +
                                        `</div>
                                        <span class="flex-no-shrink">
                                                ${icon}
                                        </span>
                                        <span class="layer-menu" attrName="${ids[i]}" attrParent="${name}_title">${ids[i]}</span>
                                        <span class="studio-layer-icon ${noeyeEnTxt} icon-noeye" id="${ids[i].replace(/ /g, "_")}_noeye">
                                            <svg viewBox="0 0 18 18">
                                                <path
                                                    d="M8 4C4 4 2 9 2 9s2 4 6 4h2c4 0 6-4 6-4s-2-5-6-5H8zM6 6.6V7c0 1.2.8 2.3 1.8 2.8h.1c.2.1.3.1.5.2H9c.4 0 .8-.1 1.2-.2 1-.5 1.8-1.6 1.8-2.8v-.4c1.5.9 2 2.4 2 2.4s-2 2.5-4 2.5H8C6 11.5 4 9 4 9s.6-1.5 2-2.4z"
                                                ></path>
                                            </svg>
                                        </span>
                                        <span class="studio-layer-icon ${eyeEnTxt} icon-eye" id="${ids[i].replace(/ /g, "_")}_eye">
                                            <svg viewBox="0 0 18 18">
                                                <path
                                                    d="M4 10s.6-1.5 2-2.4c0 0 1.1-.6 2-.8L9.6 5H8c-4 0-6 5-6 5s.6 1.1 1.7 2.1c.1-.3.2-.5.4-.8l.6-.7c-.4-.3-.7-.6-.7-.6zM11.9 5h-.1c-.2 0-.4.2-.6.3l-6 7c-.4.4-.4 1.1 0 1.5s1.1.3 1.5-.2l6-7c.6-.5 0-1.7-.8-1.6zM14.2 7.2c-.1.2-.2.3-.3.4l-.8.9c.6.8.9 1.5.9 1.5s-2 2.5-4 2.5h-.3L8.4 14H10c4 0 6-4 6-4s-.6-1.5-1.8-2.8z"
                                                ></path>
                                            </svg>
                                        </span>
                                    </div>`;	
                    } else {
                        dom += `
                                    <div class="studio-layer-tile" attrName="${name}_title">
                                        <div class="fill-canvas flex-no-shrink">` +
                                                ( multClr ? mulClrCont  : `<div class="w100 h100" style="background:${color}"></div>` ) +
                                        `</div>
                                        <span class="flex-no-shrink">
                                                ${icon}
                                        </span>
                                        <span class="layer-menu" attrName="${name}_title">${ids[i]}</span>
                                        <span class="studio-layer-icon ${noeyeEnTxt} icon-noeye" id="${name.replace(/ /g, "_")}_title_noeye">
                                            <svg viewBox="0 0 18 18">
                                                <path
                                                    d="M8 4C4 4 2 9 2 9s2 4 6 4h2c4 0 6-4 6-4s-2-5-6-5H8zM6 6.6V7c0 1.2.8 2.3 1.8 2.8h.1c.2.1.3.1.5.2H9c.4 0 .8-.1 1.2-.2 1-.5 1.8-1.6 1.8-2.8v-.4c1.5.9 2 2.4 2 2.4s-2 2.5-4 2.5H8C6 11.5 4 9 4 9s.6-1.5 2-2.4z"
                                                ></path>
                                            </svg>
                                        </span>
                                        <span class="studio-layer-icon ${eyeEnTxt} icon-eye" id="${name.replace(/ /g, "_")}_title_eye">
                                            <svg viewBox="0 0 18 18">
                                                <path
                                                    d="M4 10s.6-1.5 2-2.4c0 0 1.1-.6 2-.8L9.6 5H8c-4 0-6 5-6 5s.6 1.1 1.7 2.1c.1-.3.2-.5.4-.8l.6-.7c-.4-.3-.7-.6-.7-.6zM11.9 5h-.1c-.2 0-.4.2-.6.3l-6 7c-.4.4-.4 1.1 0 1.5s1.1.3 1.5-.2l6-7c.6-.5 0-1.7-.8-1.6zM14.2 7.2c-.1.2-.2.3-.3.4l-.8.9c.6.8.9 1.5.9 1.5s-2 2.5-4 2.5h-.3L8.4 14H10c4 0 6-4 6-4s-.6-1.5-1.8-2.8z"
                                                ></path>
                                            </svg>
                                        </span>
                                        <span class="info-icon" id="${name.replace(/ /g, "_")}_title_info">
                                            <svg viewBox="0 0 24 24">
                                                <path	
                                                    d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"
                                                ></path>
                                            </svg>
                                        </span>
                                    </div>`;
                    }			
                                    
                    
                  }
                  if(ids.length > 1) dom += `</div>`;
                  dom += `</li>`;
                  $("#studioLayerGroup").append(dom);
                }
                
                //console.log(layerColors);
              });